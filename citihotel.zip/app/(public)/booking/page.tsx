'use client'

import { useEffect, useState, Suspense } from 'react'
import { useRouter, useSearchParams } from 'next/navigation'
import { createClient } from '@/lib/supabase/client'
import { useResortSettings } from '@/hooks/useResortSettings'

interface RoomType {
  id: string; name: string; base_rate: number; max_capacity: number
  type: string; description: string | null
}
interface RoomOption {
  id: string; room_number: string; room_type_id: string
  room_types_config: { name: string; base_rate: number; max_capacity: number } | null
}

function BookingPageContent() {
  const supabase = createClient()
  const { settings: resortSettings } = useResortSettings()
  const router = useRouter()
  const searchParams = useSearchParams()

  const [roomTypes, setRoomTypes] = useState<RoomType[]>([])
  const [allRooms, setAllRooms] = useState<RoomOption[]>([])
  const [rooms, setRooms]       = useState<RoomOption[]>([])   // date-available rooms
  const [checkingAvail, setCheckingAvail] = useState(false)
  const [loading, setLoading]   = useState(false)
  const [error, setError]       = useState('')
  const [step, setStep]         = useState<1 | 2 | 3 | 4>(1)
  const [proofFile, setProofFile] = useState<File | null>(null)
  const [proofPreview, setProofPreview] = useState<string | null>(null)
  const [uploading, setUploading] = useState(false)

  // Use device LOCAL date, not UTC — toISOString() shifts to UTC and can
  // land on the wrong calendar day for PH users overnight (UTC+8).
  function toLocalDateString(d: Date) {
    const y = d.getFullYear()
    const m = String(d.getMonth() + 1).padStart(2, '0')
    const day = String(d.getDate()).padStart(2, '0')
    return `${y}-${m}-${day}`
  }
  const today    = toLocalDateString(new Date())
  const tomorrow = toLocalDateString(new Date(Date.now() + 86400000))

  // Compress image client-side before upload — targets ~300KB max
  async function compressImage(file: File): Promise<File> {
    return new Promise((resolve) => {
      const img = new Image()
      const url = URL.createObjectURL(file)

      // Some mobile browsers (in-app webviews, unsupported formats like HEIC)
      // never fire onload — without a fallback the caller hangs forever and
      // the person can never submit. Bail out to the original file instead.
      let settled = false
      const finish = (result: File) => {
        if (settled) return
        settled = true
        clearTimeout(timeoutId)
        URL.revokeObjectURL(url)
        resolve(result)
      }
      const timeoutId = setTimeout(() => finish(file), 6000)

      img.onerror = () => finish(file)
      img.onload = () => {
        const MAX_SIZE = 1200  // max width/height in px
        const MAX_BYTES = 300 * 1024  // 300KB target

        let { width, height } = img
        if (width > MAX_SIZE || height > MAX_SIZE) {
          const ratio = Math.min(MAX_SIZE / width, MAX_SIZE / height)
          width = Math.round(width * ratio)
          height = Math.round(height * ratio)
        }

        let canvas: HTMLCanvasElement
        let ctx: CanvasRenderingContext2D | null
        try {
          canvas = document.createElement('canvas')
          canvas.width = width
          canvas.height = height
          ctx = canvas.getContext('2d')
          if (!ctx) { finish(file); return }
          ctx.drawImage(img, 0, 0, width, height)
        } catch {
          finish(file)
          return
        }

        // Try quality 0.8 first, drop to 0.6 if still too big
        try {
          canvas.toBlob(blob => {
            if (!blob) { finish(file); return }
            if (blob.size <= MAX_BYTES) {
              finish(new File([blob], 'proof.jpg', { type: 'image/jpeg' }))
            } else {
              canvas.toBlob(blob2 => {
                finish(new File([blob2 ?? blob], 'proof.jpg', { type: 'image/jpeg' }))
              }, 'image/jpeg', 0.6)
            }
          }, 'image/jpeg', 0.8)
        } catch {
          finish(file)
        }
      }
      img.src = url
    })
  }

  const [form, setForm] = useState({
    check_in_date: today,
    check_out_date: tomorrow,
    num_adults: 2 as number | '',
    num_children: 0 as number | '',
    room_ids: [] as string[],
    full_name: '', email: '', phone: '', special_requests: '',
    payment_method: 'gcash' as 'gcash' | 'bank_transfer',
    payment_reference: '',
  })

  const totalPax = (Number(form.num_adults) || 0) + (Number(form.num_children) || 0)
  const selectedRooms = rooms.filter(r => form.room_ids.includes(r.id))
  const selectedRoomsCapacity = selectedRooms.reduce((s, r) => s + (r.room_types_config?.max_capacity ?? 0), 0)
  const roomsFittingAlone = rooms.filter(r => (r.room_types_config?.max_capacity ?? 0) >= totalPax)

  const nights = Math.max(1, Math.ceil(
    (new Date(form.check_out_date).getTime() - new Date(form.check_in_date).getTime()) / 86400000
  ))

  const roomLines = selectedRooms.map(r => {
    const sameTypeRooms = rooms.filter(x => x.room_type_id === r.room_type_id)
    const optionNumber = sameTypeRooms.findIndex(x => x.id === r.id) + 1
    return {
      id: r.id,
      label: `${r.room_types_config?.name}${sameTypeRooms.length > 1 ? ` — Option ${optionNumber}` : ''}`,
      rate: r.room_types_config?.base_rate ?? 0,
      amount: (r.room_types_config?.base_rate ?? 0) * nights,
    }
  })
  const subtotal = roomLines.reduce((s, l) => s + l.amount, 0)
  // Reservation fee = 50% of the ENTIRE bill (all rooms, all nights combined)
  const reservationFee = Math.ceil(subtotal * 0.5)

  // Group individual room records by room type so guests pick a
  // quantity per type ("Deluxe Room × 2") instead of seeing every
  // physical room listed out as its own repeating option.
  function groupRoomsByType(list: RoomOption[]) {
    const map = new Map<string, { room_type_id: string; name: string; base_rate: number; max_capacity: number; rooms: RoomOption[] }>()
    for (const r of list) {
      const key = r.room_type_id
      if (!map.has(key)) {
        map.set(key, {
          room_type_id: key,
          name: r.room_types_config?.name ?? 'Room',
          base_rate: r.room_types_config?.base_rate ?? 0,
          max_capacity: r.room_types_config?.max_capacity ?? 0,
          rooms: [],
        })
      }
      map.get(key)!.rooms.push(r)
    }
    return Array.from(map.values())
  }
  const availableGroups = groupRoomsByType(rooms)
  const selectedGroups = groupRoomsByType(selectedRooms).map(g => ({
    ...g,
    qty: g.rooms.length,
    amount: g.base_rate * nights * g.rooms.length,
  }))

  function setGroupQuantity(group: { room_type_id: string; rooms: RoomOption[] }, qty: number) {
    const clamped = Math.max(0, Math.min(qty, group.rooms.length))
    setForm(p => {
      const otherIds = p.room_ids.filter(id => !group.rooms.some(r => r.id === id))
      const theseIds = group.rooms.slice(0, clamped).map(r => r.id)
      return { ...p, room_ids: [...otherIds, ...theseIds] }
    })
  }

  useEffect(() => {
    Promise.all([
      supabase.from('room_types_config').select('*').eq('is_active', true).order('base_rate'),
      supabase.from('rooms').select('id, room_number, room_type_id, room_types_config(name, base_rate, max_capacity)').order('room_number'),
    ]).then(([{ data: types }, { data: roomData }]) => {
      setRoomTypes(types ?? [])
      setAllRooms((roomData as any) ?? [])
    })
  }, [])

  // Re-check availability whenever dates change (once we have rooms loaded)
  useEffect(() => {
    if (step === 1) checkRoomAvailability()
  }, [form.check_in_date, form.check_out_date, allRooms])

  async function checkRoomAvailability() {
    if (allRooms.length === 0 || !form.check_in_date || !form.check_out_date) return
    if (form.check_in_date >= form.check_out_date) { setRooms([]); return }

    setCheckingAvail(true)

    // NOTE: only valid booking_status enum values here — pending, confirmed,
    // checked_in are the "active/blocking" statuses. ('reserved' is NOT a
    // valid enum value and must never appear in this filter.)
    const { data: overlappingBookings, error: overlapError } = await supabase
      .from('vw_room_booking_ranges')
      .select('room_id')
      .not('room_id', 'is', null)
      .lt('check_in_date', form.check_out_date)
      .gt('check_out_date', form.check_in_date)

    // Fail CLOSED, not open: if we can't verify which rooms are booked
    // (e.g. an RLS permission error), never fall back to "show everything
    // as available" — that risks double-booking a room that's taken.
    if (overlapError) {
      console.error('Availability check failed:', overlapError.message)
      setRooms([])
      setError('Unable to check room availability right now. Please refresh and try again.')
      setCheckingAvail(false)
      return
    }

    const bookedRoomIds = new Set((overlappingBookings ?? []).map(b => b.room_id))
    const availableForDates = allRooms.filter(r => !bookedRoomIds.has(r.id))

    setError('')
    setRooms(availableForDates)
    setForm(p => ({ ...p, room_ids: p.room_ids.filter(id => availableForDates.some(r => r.id === id)) }))
    setCheckingAvail(false)
  }

  function goToStep2() {
    setError('')
    // Defense-in-depth: some mobile browsers' native date picker doesn't
    // enforce the `min` attribute, so re-validate here regardless of what
    // the picker allowed through.
    if (form.check_in_date < today) {
      setError('Check-in date cannot be in the past. Please pick a valid date.')
      return
    }
    if (form.check_out_date <= form.check_in_date) {
      setError('Check-out date must be after check-in date.')
      return
    }
    if (form.room_ids.length === 0) { setError('Please select at least one room.'); return }
    if (selectedRoomsCapacity < totalPax) {
      setError(`Selected room(s) only fit ${selectedRoomsCapacity} guest(s) — you need room for ${totalPax}. Please select more rooms.`)
      return
    }
    setStep(2)
  }

  async function submitBooking() {
    if (form.check_in_date < today) { setError('Check-in date cannot be in the past.'); return }
    if (form.check_out_date <= form.check_in_date) { setError('Check-out date must be after check-in date.'); return }
    if (!form.full_name) { setError('Please enter your full name.'); return }
    if (!form.email && !form.phone) { setError('Please provide an email or phone number.'); return }
    if (!proofFile) { setError('Please upload your proof of payment.'); return }
    if (!form.payment_reference) { setError('Please enter your payment reference number.'); return }

    // Defensive: if a number field was left empty (e.g. submit tapped before
    // blur fired on mobile), fall back to its minimum instead of sending 0/''.
    const numAdults = form.num_adults === '' || Number(form.num_adults) < 1 ? 1 : Number(form.num_adults)
    const numChildren = form.num_children === '' ? 0 : Number(form.num_children)
    if (numAdults !== form.num_adults || numChildren !== form.num_children) {
      setForm(p => ({ ...p, num_adults: numAdults, num_children: numChildren }))
    }

    setLoading(true)
    setError('')

    try {
      // Re-verify availability right before submitting
      const { data: freshOverlaps, error: freshOverlapError } = await supabase
        .from('vw_room_booking_ranges')
        .select('room_id')
        .in('room_id', form.room_ids)
        .lt('check_in_date', form.check_out_date)
        .gt('check_out_date', form.check_in_date)

      // Fail closed: if we can't verify, don't let the booking through —
      // that's how a room ends up double-booked.
      if (freshOverlapError) {
        throw new Error('Unable to verify room availability. Please try again.')
      }

      if (freshOverlaps && freshOverlaps.length > 0) {
        setError('One of your selected rooms was just booked by someone else. Please go back and reselect.')
        setLoading(false)
        checkRoomAvailability()
        return
      }

      // Upload proof of payment to storage
      setUploading(true)
      const fileExt = proofFile.name.split('.').pop()
      const fileName = `${Date.now()}-${Math.random().toString(36).slice(2, 8)}.${fileExt}`
      const { error: uploadError } = await supabase.storage
        .from('payment-proofs')
        .upload(fileName, proofFile)

      if (uploadError) throw new Error('Failed to upload payment proof: ' + uploadError.message)

      const { data: urlData } = supabase.storage.from('payment-proofs').getPublicUrl(fileName)
      const proofUrl = urlData.publicUrl
      setUploading(false)

      // Guest + booking rows are created server-side (service role) since
      // this visitor is anonymous and the anon browser client is (correctly)
      // blocked by RLS from writing to `guests` / `bookings` directly.
      const res = await fetch('/api/public/booking', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          full_name: form.full_name,
          email: form.email || null,
          phone: form.phone || null,
          check_in_date: form.check_in_date,
          check_out_date: form.check_out_date,
          num_adults: numAdults,
          num_children: numChildren,
          room_lines: roomLines.map(rl => ({ room_id: rl.id, amount: rl.amount })),
          special_requests: form.special_requests || null,
          payment_proof_url: proofUrl,
          payment_reference: form.payment_reference,
          payment_method: form.payment_method,
        }),
      })
      const result = await res.json()
      if (!result.success) throw new Error(result.error || 'Something went wrong. Please try again.')

      const { primary_booking_id, group_number } = result.data
      router.push(`/booking/confirmation/${primary_booking_id}${group_number ? `?group=${group_number}&count=${roomLines.length}` : ''}`)

    } catch (err: any) {
      const isDoubleBooking = err.message?.includes('no_overlapping_room_bookings') || err.code === '23P01'
      setError(isDoubleBooking
        ? 'One of your selected rooms was just booked by someone else. Please go back and reselect.'
        : (err.message || 'Something went wrong. Please try again.'))
      setLoading(false)
      setUploading(false)
    }
  }

  return (
    <>
      <section className="bg-gradient-to-br from-blue-900 to-teal-700 text-white py-16">
        <div className="max-w-3xl mx-auto px-4 text-center">
          <h1 className="pub-hero-in text-4xl font-bold mb-3">Book Your Overnight Stay</h1>
          <p className="pub-hero-in text-blue-100" style={{ animationDelay: '120ms' }}>Reserve now, pay the 50% reservation fee on arrival. Easy and hassle-free.</p>
        </div>
      </section>

      <section className="py-16 bg-gray-50">
        <div className="max-w-2xl mx-auto px-4">

          {/* Step indicator */}
          <div className="flex items-center gap-2 mb-10">
            {[
              { n: 1, label: 'Rooms & Dates' },
              { n: 2, label: 'Your Details' },
              { n: 3, label: 'Review' },
              { n: 4, label: 'Pay Deposit' },
            ].map((s, i) => (
              <div key={s.n} className="flex items-center gap-2 flex-1">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-semibold flex-shrink-0 ${
                  step >= s.n ? 'bg-blue-700 text-white' : 'bg-gray-200 text-gray-500'
                }`}>{s.n}</div>
                <span className={`text-xs hidden sm:block ${step >= s.n ? 'text-blue-700 font-medium' : 'text-gray-400'}`}>{s.label}</span>
                {i < 3 && <div className={`flex-1 h-0.5 ${step > s.n ? 'bg-blue-700' : 'bg-gray-200'}`} />}
              </div>
            ))}
          </div>

          {error && (
            <div className="mb-6 bg-red-50 border border-red-200 rounded-xl p-4 text-sm text-red-600">{error}</div>
          )}

          <div key={step} className="pub-step-in">

          {/* Step 1: Guests, Dates & Rooms */}
          {step === 1 && (
            <div className="bg-white rounded-2xl p-6 shadow-sm space-y-5">
              <h2 className="text-lg font-semibold text-gray-800">Guests & Dates</h2>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1.5">Adults</label>
                  <input type="number" inputMode="numeric" min={1} max={20} value={form.num_adults}
                    onChange={e => {
                      const v = e.target.value
                      setForm(p => ({ ...p, num_adults: v === '' ? '' : Math.max(0, parseInt(v) || 0) }))
                    }}
                    onBlur={() => setForm(p => ({ ...p, num_adults: (p.num_adults === '' || Number(p.num_adults) < 1) ? 1 : p.num_adults }))}
                    className="w-full px-4 py-3 border border-gray-200 rounded-xl text-sm text-gray-900 bg-white" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1.5">Children</label>
                  <input type="number" inputMode="numeric" min={0} max={20} value={form.num_children}
                    onChange={e => {
                      const v = e.target.value
                      setForm(p => ({ ...p, num_children: v === '' ? '' : Math.max(0, parseInt(v) || 0) }))
                    }}
                    onBlur={() => setForm(p => ({ ...p, num_children: p.num_children === '' ? 0 : p.num_children }))}
                    className="w-full px-4 py-3 border border-gray-200 rounded-xl text-sm text-gray-900 bg-white" />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1.5">Check-in Date</label>
                  <input type="date" value={form.check_in_date} min={today}
                    onChange={e => setForm(p => ({ ...p, check_in_date: e.target.value }))}
                    className="w-full px-4 py-3 border border-gray-200 rounded-xl text-sm text-gray-900 bg-white" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1.5">Check-out Date</label>
                  <input type="date" value={form.check_out_date} min={form.check_in_date}
                    onChange={e => setForm(p => ({ ...p, check_out_date: e.target.value }))}
                    className="w-full px-4 py-3 border border-gray-200 rounded-xl text-sm text-gray-900 bg-white" />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Select Room(s) <span className="text-xs text-gray-400 font-normal">— select multiple if needed for your group</span>
                </label>

                {checkingAvail ? (
                  <div className="text-sm text-gray-400 py-4 text-center">Checking availability...</div>
                ) : rooms.length === 0 ? (
                  <div className="text-sm text-amber-600 bg-amber-50 rounded-xl p-4">
                    No rooms available for these dates. Please try different dates.
                  </div>
                ) : (
                  <>
                    {roomsFittingAlone.length === 0 && (
                      <div className="text-xs text-blue-600 bg-blue-50 rounded-lg p-2.5 mb-2">
                        No single room fits {totalPax} guest(s) — select multiple rooms below to combine capacity.
                      </div>
                    )}
                    <div className="space-y-2 max-h-72 overflow-y-auto">
                      {availableGroups.map(g => {
                        const selectedQty = form.room_ids.filter(id => g.rooms.some(r => r.id === id)).length
                        const tooSmallAlone = g.max_capacity < totalPax && form.room_ids.length === 0
                        return (
                          <div key={g.room_type_id} className={`flex items-center gap-4 border-2 rounded-xl p-4 transition-all duration-200 ${
                            selectedQty > 0 ? 'border-blue-500 bg-blue-50' : 'border-gray-200'
                          } ${tooSmallAlone ? 'opacity-50' : ''}`}>
                            <div className="flex-1">
                              <div className="font-medium text-gray-800">{g.name}</div>
                              <div className="text-sm text-gray-500">Up to {g.max_capacity} guests per room · {g.rooms.length} available</div>
                            </div>
                            <div className="text-right">
                              <div className="font-bold text-blue-700">₱{Number(g.base_rate).toLocaleString()}</div>
                              <div className="text-xs text-gray-400">per night</div>
                            </div>
                            <div className="flex items-center gap-2 flex-shrink-0">
                              <button type="button" onClick={() => setGroupQuantity(g, selectedQty - 1)} disabled={selectedQty === 0}
                                className="w-8 h-8 rounded-full border border-gray-300 text-gray-600 disabled:opacity-30 flex items-center justify-center hover:bg-gray-50">−</button>
                              <span className="w-5 text-center font-medium text-gray-800">{selectedQty}</span>
                              <button type="button" onClick={() => setGroupQuantity(g, selectedQty + 1)} disabled={selectedQty >= g.rooms.length}
                                className="w-8 h-8 rounded-full border border-gray-300 text-gray-600 disabled:opacity-30 flex items-center justify-center hover:bg-gray-50">+</button>
                            </div>
                          </div>
                        )
                      })}
                    </div>
                  </>
                )}

                {form.room_ids.length > 0 && (
                  <div className={`mt-2 text-xs rounded-lg px-3 py-2 ${
                    selectedRoomsCapacity >= totalPax ? 'text-blue-600 bg-blue-50' : 'text-red-600 bg-red-50'
                  }`}>
                    {form.room_ids.length} room(s) selected — fits {selectedRoomsCapacity} guest(s)
                    {selectedRoomsCapacity < totalPax && ` — short by ${totalPax - selectedRoomsCapacity}, select more rooms`}
                  </div>
                )}
              </div>

              {roomLines.length > 0 && (
                <div className="bg-blue-50 rounded-xl p-4 text-sm">
                  {selectedGroups.map(g => (
                    <div key={g.room_type_id} className="flex justify-between text-gray-600 mb-1">
                      <span>{g.name}{g.qty > 1 ? ` × ${g.qty} rooms` : ''} × {nights} night{nights > 1 ? 's' : ''}</span>
                      <span>₱{g.amount.toLocaleString()}</span>
                    </div>
                  ))}
                  <div className="flex justify-between font-semibold text-blue-700 border-t border-blue-200 pt-1.5 mt-1.5">
                    <span>Reservation fee (50% of total bill)</span>
                    <span>₱{reservationFee.toLocaleString()}</span>
                  </div>
                  <div className="text-xs text-gray-400 mt-1">Balance of ₱{(subtotal - reservationFee).toLocaleString()} due on arrival.</div>
                </div>
              )}

              <button onClick={goToStep2} disabled={form.room_ids.length === 0 || selectedRoomsCapacity < totalPax}
                className="w-full bg-blue-700 hover:bg-blue-800 disabled:bg-blue-300 text-white py-3.5 rounded-xl font-semibold transition-all duration-200 hover:-translate-y-0.5 hover:shadow-lg active:scale-[0.98] disabled:hover:translate-y-0 disabled:hover:shadow-none">
                Continue →
              </button>
            </div>
          )}

          {/* Step 2: Guest Details */}
          {step === 2 && (
            <div className="bg-white rounded-2xl p-6 shadow-sm space-y-5">
              <div className="flex items-center gap-3">
                <button onClick={() => setStep(1)} className="text-gray-400 hover:text-gray-600 text-sm">← Back</button>
                <h2 className="text-lg font-semibold text-gray-800">Your Details</h2>
              </div>

              <div className="bg-green-50 border border-green-200 rounded-xl p-3 text-sm text-green-700">
                ✓ {form.room_ids.length} room{form.room_ids.length > 1 ? 's' : ''} selected, fits {selectedRoomsCapacity} guests
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1.5">Full Name *</label>
                <input value={form.full_name} onChange={e => setForm(p => ({ ...p, full_name: e.target.value }))}
                  placeholder="Juan Dela Cruz"
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl text-sm text-gray-900 bg-white" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1.5">Email Address</label>
                <input type="email" value={form.email} onChange={e => setForm(p => ({ ...p, email: e.target.value }))}
                  placeholder="you@email.com"
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl text-sm text-gray-900 bg-white" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1.5">Phone Number</label>
                <input value={form.phone} onChange={e => setForm(p => ({ ...p, phone: e.target.value }))}
                  placeholder="+63 9XX XXX XXXX"
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl text-sm text-gray-900 bg-white" />
                <p className="text-xs text-gray-400 mt-1">Please provide at least one contact method.</p>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1.5">Special Requests (optional)</label>
                <textarea value={form.special_requests} onChange={e => setForm(p => ({ ...p, special_requests: e.target.value }))}
                  rows={3} placeholder="e.g. Extra pillows, early check-in, adjacent rooms..."
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl text-sm text-gray-900 bg-white resize-none" />
              </div>

              <button onClick={() => { if (!form.full_name || (!form.email && !form.phone)) { setError('Please fill in required fields.'); return }; setError(''); setStep(3) }}
                className="w-full bg-blue-700 hover:bg-blue-800 text-white py-3.5 rounded-xl font-semibold transition-colors">
                Review Booking →
              </button>
            </div>
          )}

          {/* Step 3: Review & Confirm */}
          {step === 3 && (
            <div className="bg-white rounded-2xl p-6 shadow-sm space-y-5">
              <div className="flex items-center gap-3">
                <button onClick={() => setStep(2)} className="text-gray-400 hover:text-gray-600 text-sm">← Back</button>
                <h2 className="text-lg font-semibold text-gray-800">Review Your Booking</h2>
              </div>

              <div className="border border-gray-100 rounded-xl overflow-hidden">
                <div className="bg-gray-50 px-4 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wide">Booking Summary</div>
                <div className="p-4 space-y-3 text-sm">
                  {selectedGroups.map(g => (
                    <div key={g.room_type_id} className="flex justify-between"><span className="text-gray-500">{g.name}{g.qty > 1 ? ` × ${g.qty}` : ''}</span><span className="font-medium">₱{g.amount.toLocaleString()}</span></div>
                  ))}
                  <div className="flex justify-between"><span className="text-gray-500">Check-in</span><span className="font-medium">{new Date(form.check_in_date).toLocaleDateString('en-PH', { weekday: 'short', month: 'short', day: 'numeric', year: 'numeric' })}</span></div>
                  <div className="flex justify-between"><span className="text-gray-500">Check-out</span><span className="font-medium">{new Date(form.check_out_date).toLocaleDateString('en-PH', { weekday: 'short', month: 'short', day: 'numeric', year: 'numeric' })}</span></div>
                  <div className="flex justify-between"><span className="text-gray-500">Duration</span><span className="font-medium">{nights} night{nights > 1 ? 's' : ''}</span></div>
                  <div className="flex justify-between"><span className="text-gray-500">Guests</span><span className="font-medium">{Number(form.num_adults) || 0} adult{Number(form.num_adults) !== 1 ? 's' : ''}{Number(form.num_children) > 0 ? `, ${Number(form.num_children)} child${Number(form.num_children) > 1 ? 'ren' : ''}` : ''}</span></div>
                </div>
                <div className="border-t border-gray-100 px-4 py-3 space-y-2 text-sm">
                  <div className="flex justify-between"><span className="text-gray-500">Total Bill</span><span>₱{subtotal.toLocaleString()}</span></div>
                  <div className="flex justify-between font-semibold text-blue-700"><span>Reservation Fee (pay on arrival)</span><span>₱{reservationFee.toLocaleString()}</span></div>
                  <div className="flex justify-between text-gray-400 text-xs"><span>Balance on check-in</span><span>₱{(subtotal - reservationFee).toLocaleString()}</span></div>
                </div>
              </div>

              <div className="border border-gray-100 rounded-xl overflow-hidden">
                <div className="bg-gray-50 px-4 py-3 text-xs font-semibold text-gray-500 uppercase tracking-wide">Guest Details</div>
                <div className="p-4 space-y-2 text-sm">
                  <div className="flex justify-between"><span className="text-gray-500">Name</span><span className="font-medium">{form.full_name}</span></div>
                  {form.email && <div className="flex justify-between"><span className="text-gray-500">Email</span><span>{form.email}</span></div>}
                  {form.phone && <div className="flex justify-between"><span className="text-gray-500">Phone</span><span>{form.phone}</span></div>}
                  {form.special_requests && <div className="flex justify-between gap-4"><span className="text-gray-500 flex-shrink-0">Requests</span><span className="text-right">{form.special_requests}</span></div>}
                </div>
              </div>

              <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 text-sm text-amber-700">
                <strong>Next step:</strong> You'll pay the ₱{reservationFee.toLocaleString()} reservation fee via GCash or bank transfer, then upload your proof of payment. Your booking is confirmed once we verify the payment.
              </div>

              <button onClick={() => setStep(4)}
                className="w-full bg-blue-700 hover:bg-blue-800 text-white py-4 rounded-xl font-semibold text-lg transition-all duration-200 hover:-translate-y-0.5 hover:shadow-lg active:scale-[0.98]">
                Continue to Payment →
              </button>
            </div>
          )}

          {/* Step 4: Pay deposit & upload proof */}
          {step === 4 && (
            <div className="bg-white rounded-2xl p-6 shadow-sm space-y-5">
              <div className="flex items-center gap-3">
                <button onClick={() => setStep(3)} className="text-gray-400 hover:text-gray-600 text-sm">← Back</button>
                <h2 className="text-lg font-semibold text-gray-800">Pay Reservation Fee</h2>
              </div>

              <div className="bg-blue-50 rounded-xl p-4 text-center">
                <div className="text-xs text-blue-500 mb-1">Amount to Pay</div>
                <div className="text-3xl font-bold text-blue-700">₱{reservationFee.toLocaleString()}</div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Payment Method</label>
                <div className="grid grid-cols-2 gap-3">
                  <button type="button" onClick={() => setForm(p => ({ ...p, payment_method: 'gcash' }))}
                    className={`p-4 rounded-xl border-2 text-sm font-medium transition-colors ${
                      form.payment_method === 'gcash' ? 'border-blue-500 bg-blue-50 text-blue-700' : 'border-gray-200 text-gray-600'
                    }`}>
                    📱 GCash
                  </button>
                  <button type="button" onClick={() => setForm(p => ({ ...p, payment_method: 'bank_transfer' }))}
                    className={`p-4 rounded-xl border-2 text-sm font-medium transition-colors ${
                      form.payment_method === 'bank_transfer' ? 'border-blue-500 bg-blue-50 text-blue-700' : 'border-gray-200 text-gray-600'
                    }`}>
                    🏦 Bank Transfer
                  </button>
                </div>
              </div>

              {form.payment_method === 'gcash' ? (
                <div className="bg-gray-50 rounded-xl p-4 text-sm">
                  <div className="font-medium text-gray-700 mb-1">Send payment to:</div>
                  <div className="text-gray-600">GCash: <strong>{resortSettings.gcash_number || '—'}</strong></div>
                  <div className="text-gray-600">Account Name: <strong>{resortSettings.resort_name}</strong></div>
                </div>
              ) : (
                <div className="bg-gray-50 rounded-xl p-4 text-sm">
                  <div className="font-medium text-gray-700 mb-1">Bank Transfer Details:</div>
                  <div className="text-gray-600">Bank: <strong>{resortSettings.bank_name || '—'}</strong></div>
                  <div className="text-gray-600">Account Name: <strong>{resortSettings.resort_name}</strong></div>
                  <div className="text-gray-600">Account Number: <strong>{resortSettings.bank_account_number || '—'}</strong></div>
                </div>
              )}

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1.5">Reference Number *</label>
                <input value={form.payment_reference} onChange={e => setForm(p => ({ ...p, payment_reference: e.target.value }))}
                  placeholder="e.g. GCash reference number"
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl text-sm text-gray-900 bg-white" />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1.5">Upload Proof of Payment *</label>
                <input
                  type="file"
                  accept="image/*"
                  onChange={async e => {
                    const file = e.target.files?.[0]
                    if (!file) return
                    if (file.size > 10 * 1024 * 1024) {
                      setError('File too large. Please upload an image under 10MB.')
                      return
                    }
                    const compressed = await compressImage(file)
                    setProofFile(compressed)
                    setProofPreview(URL.createObjectURL(compressed))
                  }}
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl text-sm text-gray-900 bg-white"
                />
                {proofPreview && (
                  <img src={proofPreview} alt="Payment proof preview" className="mt-3 rounded-xl max-h-64 mx-auto border border-gray-200" />
                )}
                <p className="text-xs text-gray-400 mt-1">Screenshot of your GCash/bank transfer confirmation. Image will be automatically compressed.</p>
              </div>

              <button onClick={submitBooking} disabled={loading || uploading || !proofFile || !form.payment_reference}
                className="w-full bg-blue-700 hover:bg-blue-800 disabled:bg-blue-300 text-white py-4 rounded-xl font-semibold text-lg transition-all duration-200 hover:-translate-y-0.5 hover:shadow-lg active:scale-[0.98] disabled:hover:translate-y-0 disabled:hover:shadow-none">
                {uploading ? 'Uploading proof...' : loading ? 'Submitting...' : 'Submit Booking Request'}
              </button>
              <p className="text-xs text-gray-400 text-center">
                We'll verify your payment and confirm your booking within 24 hours.
              </p>
            </div>
          )}

          </div>
        </div>
      </section>
    </>
  )
}

export default function BookingPage() {
  return (
    <Suspense fallback={null}>
      <BookingPageContent />
    </Suspense>
  )
}
